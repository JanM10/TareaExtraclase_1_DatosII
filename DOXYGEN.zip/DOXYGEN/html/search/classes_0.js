var searchData=
[
  ['collector_19',['Collector',['../class_collector.html',1,'']]]
];
