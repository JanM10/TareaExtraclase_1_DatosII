var searchData=
[
  ['setdata_37',['SetData',['../class_node.html#ae87befa841ab1b6a141f78c91730c0a3',1,'Node']]],
  ['setnext_38',['SetNext',['../class_node.html#a3fcf07b7346e6cf56ad4322858ef31d7',1,'Node']]],
  ['setpuntero_39',['SetPuntero',['../class_node.html#abd1ecb84a84eb2a80db3024c288e4c80',1,'Node']]]
];
