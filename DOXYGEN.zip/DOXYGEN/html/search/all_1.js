var searchData=
[
  ['collector_1',['Collector',['../class_collector.html',1,'Collector'],['../class_collector.html#ad60b06491094b8fddf25502cf162cdf6',1,'Collector::Collector()']]]
];
