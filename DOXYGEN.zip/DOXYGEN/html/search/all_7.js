var searchData=
[
  ['m_5fsize_9',['m_Size',['../class_collector.html#a77a7246ddb518881807a4b3822747ab1',1,'Collector']]]
];
