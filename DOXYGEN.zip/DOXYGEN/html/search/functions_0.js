var searchData=
[
  ['borrardircolector_22',['BorrarDirColector',['../class_collector.html#a4d0f2bd0d64a91a8474d3e7b2dd5b95e',1,'Collector']]]
];
