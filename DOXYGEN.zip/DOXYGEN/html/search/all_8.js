var searchData=
[
  ['node_10',['Node',['../class_node.html',1,'Node'],['../class_node.html#ad7a34779cad45d997bfd6d3d8043c75f',1,'Node::Node()'],['../class_node.html#a8b133a02a0b993c4e07eabfa75482fdd',1,'Node::Node(int _data, Node *_next)'],['../class_node.html#ac1a5a0126c08c719d854d55798ac0d0c',1,'Node::Node(void *puntero, Node *_next)']]]
];
