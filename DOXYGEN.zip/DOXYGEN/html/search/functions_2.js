var searchData=
[
  ['display_24',['Display',['../class_node.html#a3379bb8e49b9d84eac87176480995266',1,'Node']]]
];
