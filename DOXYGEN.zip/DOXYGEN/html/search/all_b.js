var searchData=
[
  ['revisarcollector_15',['RevisarCollector',['../class_collector.html#a9b9ac34ef5aacbd18f73d94f63fe336a',1,'Collector']]]
];
