var searchData=
[
  ['getdata_4',['GetData',['../class_node.html#a280b29a39e5117f08c77603ea3ea3845',1,'Node']]],
  ['getnext_5',['GetNext',['../class_node.html#a6f8729374beb27838792dc6ef81124e8',1,'Node']]],
  ['getpuntero_6',['GetPuntero',['../class_collector.html#a3642b9994d67ed2d5d99924b5ffe8a41',1,'Collector::GetPuntero()'],['../class_node.html#a3a9594886621465eaf91a0ac0e57480c',1,'Node::GetPuntero()']]]
];
