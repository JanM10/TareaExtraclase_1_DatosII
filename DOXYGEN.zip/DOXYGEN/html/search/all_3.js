var searchData=
[
  ['eliminardato_3',['EliminarDato',['../class_list.html#a57a5d2273e22402410801fc15ce916e2',1,'List']]]
];
