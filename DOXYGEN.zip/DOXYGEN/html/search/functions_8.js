var searchData=
[
  ['operator_20delete_32',['operator delete',['../class_node.html#a172153efdb501e704f1c9d7e5fd12d68',1,'Node']]],
  ['operator_20new_33',['operator new',['../class_node.html#a8c309be556d255925788c02ff976354a',1,'Node']]]
];
