var searchData=
[
  ['insertar_7',['Insertar',['../class_collector.html#acf5b3c7ec1393b41c092192b3fa82564',1,'Collector::Insertar()'],['../class_list.html#ac8b9b121e22019ce8ed309c1108cbfaf',1,'List::Insertar()']]]
];
